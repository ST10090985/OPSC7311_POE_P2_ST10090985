**README FILE**

**Group members - Group 14** - OPSC7311 POE part2 

- Shameel Reddy ST10090985
- Sethabile Dlamini ST10198677
- Luyanda nkosi ST10069575
- Morena Nkosi ST10091000
- Wavhudi Tshibubudze ST10143181


**Requirements**
- Android studio Iguana | 2023.2.1 or higher
- Sdk 21 or higher

**How to access**
- Unzip the "POE_Part2_GroupAssignment_KairoChronicles" folder in your desired location
- Open the unzipped file in Android studio Iguana | 2023.2.1 or higher
- Run it via Android studio Iguana | 2023.2.1 or higher
- If you run into error there are a few suggestions further below 

##Kairo Chronicles##
Kairo Chronicles is an Android application designed to help users effectively manage
and track their time. It provides a comprehensive platform to create, store, and review
timesheet entries, add and manage task categories, and capture images as part of the
entries. It's suited for personal or small team use, perfect for freelancers or anyone
interested in detailed time management.
------

##Features##
Manage Timesheet Entries: Add, edit, and review timesheet entries with details
such as start and end times, descriptions, and categories.
Category Management: Users can add and manage custom categories for their
timesheet entries.
Photo Attachments: Attach photos to timesheet entries, either by capturing new
photos directly through the app or selecting from the gallery.
Time and Date Pickers: Interactive selectors for date and time ensure that entries
are logged with accuracy.
Login System: Simple login functionality to keep your entries secure.
Goal Setting: Users can set minimum and maximum hours for tasks, helping
them stay on track with their objectives.
Installation
This application can be installed on any Android device running Android 5.0 (Lollipop) or
higher. To install Kairo Chronicles, simply download the APK file from the releases
section and install it on your device. Make sure to enable installation from unknown
sources in your device's settings.
-----

##Usage##
After installation, follow these steps to get started with Kairo Chronicles:
1. Log in to the App: Start by logging into the application using default credentials or
create your account (if functionality available). (Default credentials: username: "user", password: "1234")
2. Add or Review Entries: Navigate through the app to add new timesheet entries or
review existing ones.
3. Manage Categories: You can create and manage categories that can be tagged to
different timesheet entries.
4. Attach Photos: Attach photos to your timesheet entries by either taking new photos or
selecting from existing ones in your gallery.
Permissions
Kairo Chronicles requires the following permissions:
- Camera: To take photos to attach to timesheet entries.
- Storage: To save and retrieve photos from your device.
- Internet: If the application needs to sync data with a server or if updates are needed.
License
This project is licensed under the MIT License - see the LICENSE.md file for details.
Acknowledgments
- Android SDK: For providing the foundation to build the app.
- Any third-party libraries or APIs used in the app.

!!!IF YOU RUN INTO THE FILE EXTENSION TOO LONG ERROR!!!
This is due to the file explorer not being able to handle the name being to long from my undertstanding.

Hence this is what you will need to do to fix it:
- Change the file name to a shorter name such as "A" temporarily, the zip file and the file in the zip. 
- Unzip the folder to your desired location
- rename the unzipped folder back to its original name to prevent any potential package name errors. The original name >> "POE_Part2_GroupAssignment_KairoChronicles"
- Open it in Android studio and you should be good to go.

!!!IF YOU RUN INTO THE SDK LOCATION ERROR!!!
I believe this is due to the different sdk installation paths.

The simplest solution I found:
- Open the application
- Open the settings for the sdk path
- remove the path, apply it
- Close the application
- Open it and it should recorrect it

- Alternatively you could add your sdk path

